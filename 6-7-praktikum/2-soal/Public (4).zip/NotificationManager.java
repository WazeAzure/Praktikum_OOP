import java.util.List;

public class NotificationManager {
    private List<Service> services;

    public NotificationManager(List<Service> services) {
    }

    public void addService(Service service) {
        // Tambahkan service ke dalam list services
    }

    public List<Service> getServices() {
        // Mengembalikan list services
    }

    public void removeService(Service service) {
        // Hapus service dari dalam list services
    }

    public void notifyService(String message) {
        // Kirim pesan ke user dengan isi pesan message
    }
}
