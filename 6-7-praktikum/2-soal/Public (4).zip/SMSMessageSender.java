public class SMSMessageSender implements IMessageSender{
    private String servicePhone;

    public SMSMessageSender(String servicePhone) {
    }

    public void sendMessage(User data, String message) {
        // Kirim SMS ke user dengan isi pesan message, print dengan format
        // From: <servicePhone>
        // To: <name> <phoneUser>
        // Message: <message>
        // Masing-masing diikuti dengan newline
    }
}
